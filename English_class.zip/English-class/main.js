

function notice1(){
    document.getElementById("all-notice").style.display="block";         //文字的隐藏与显示
    document.getElementById("college-profile").style.display="none";
    document.getElementById("class-profile").style.display="none";
    document.getElementById("news-college").style.display="none";
    document.getElementById("special-news").style.display="none";


    document.getElementById("all-1").style.backgroundColor="#BA55D3";     //按钮的颜色变话
    document.getElementById("all-2").style.backgroundColor="#D3D3D3";
    document.getElementById("all-3").style.backgroundColor="#D3D3D3";
    document.getElementById("all-4").style.backgroundColor="#D3D3D3";
    document.getElementById("all-5").style.backgroundColor="#D3D3D3";
    }

function notice2(){
    document.getElementById("all-notice").style.display="none";
    document.getElementById("college-profile").style.display="block";
    document.getElementById("class-profile").style.display="none";
    document.getElementById("news-college").style.display="none";
    document.getElementById("special-news").style.display="none";


    document.getElementById("all-1").style.backgroundColor="#D3D3D3";
    document.getElementById("all-2").style.backgroundColor="#BA55D3";
    document.getElementById("all-3").style.backgroundColor="#D3D3D3";
    document.getElementById("all-4").style.backgroundColor="#D3D3D3";
    document.getElementById("all-5").style.backgroundColor="#D3D3D3";
    }

function notice3() {
    document.getElementById("all-notice").style.display="none";
    document.getElementById("college-profile").style.display="none";
    document.getElementById("class-profile").style.display="block";
    document.getElementById("news-college").style.display="none";
    document.getElementById("special-news").style.display="none";


    document.getElementById("all-1").style.backgroundColor="#D3D3D3";
    document.getElementById("all-2").style.backgroundColor="#D3D3D3";
    document.getElementById("all-3").style.backgroundColor="#BA55D3";
    document.getElementById("all-4").style.backgroundColor="#D3D3D3";
    document.getElementById("all-5").style.backgroundColor="#D3D3D3";
    }

function notice4() {
    document.getElementById("all-notice").style.display="none";
    document.getElementById("college-profile").style.display="none";
    document.getElementById("class-profile").style.display="none";
    document.getElementById("all-notice").style.display="block";
    document.getElementById("special-news").style.display="none";


    document.getElementById("all-1").style.backgroundColor="#D3D3D3";
    document.getElementById("all-2").style.backgroundColor="#D3D3D3";
    document.getElementById("all-3").style.backgroundColor="#D3D3D3";
    document.getElementById("all-4").style.backgroundColor="#BA55D3";
    document.getElementById("all-5").style.backgroundColor="#D3D3D3";
    }

function notice5() {
    document.getElementById("all-notice").style.display="none";
    document.getElementById("college-profile").style.display="none";
    document.getElementById("class-profile").style.display="none";
    document.getElementById("news-college").style.display="none";
    document.getElementById("special-news").style.display="block";


    document.getElementById("all-1").style.backgroundColor="#D3D3D3";
    document.getElementById("all-2").style.backgroundColor="#D3D3D3";
    document.getElementById("all-3").style.backgroundColor="#D3D3D3";
    document.getElementById("all-4").style.backgroundColor="#D3D3D3";
    document.getElementById("all-5").style.backgroundColor="#BA55D3";
    }


